---
layout: post
title: This is just an irresponsible amount of sermon, tbh
date: '2016-12-18 19:21:28'
---

<div class="storify"><iframe src="//storify.com/pastordan/jesus-mary-but-mostly-joseph/embed?border=false&template=slideshow" width="100%" height="750" frameborder="no" allowtransparency="true"></iframe><script src="//storify.com/pastordan/jesus-mary-but-mostly-joseph.js?border=false&template=slideshow"></script><noscript>[<a href="//storify.com/pastordan/jesus-mary-but-mostly-joseph" target="_blank">View the story "Jesus, Mary, but mostly, Joseph" on Storify</a>]</noscript></div>

But wait, there's more!

<div class="storify"><iframe src="//storify.com/pastordan/how-in-the-heck-do-i-have-more-to-say-about-mary-a/embed?border=false&template=slideshow" width="100%" height="750" frameborder="no" allowtransparency="true"></iframe><script src="//storify.com/pastordan/how-in-the-heck-do-i-have-more-to-say-about-mary-a.js?border=false&template=slideshow"></script><noscript>[<a href="//storify.com/pastordan/how-in-the-heck-do-i-have-more-to-say-about-mary-a" target="_blank">View the story "How in the heck do I have more to say about Mary and Joseph?" on Storify</a>]</noscript></div>