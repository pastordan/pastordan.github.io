---
layout: post
title: Hope somebody filled your stockings with glee
date: '2016-12-06 20:31:57'
---

<div class="storify"><iframe src="//storify.com/pastordan/hope-somebody-filled-your-stockings-with-glee/embed?border=false&template=slideshow" width="100%" height="750" frameborder="no" allowtransparency="true"></iframe><script src="//storify.com/pastordan/hope-somebody-filled-your-stockings-with-glee.js?border=false&template=slideshow"></script><noscript>[<a href="//storify.com/pastordan/hope-somebody-filled-your-stockings-with-glee" target="_blank">View the story "Hope somebody filled your stockings with glee" on Storify</a>]</noscript></div>

(As always, [here's a link](https://storify.com/pastordan/hope-somebody-filled-your-stockings-with-glee) in case the Storify embed doesn't work.)