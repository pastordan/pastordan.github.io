---
layout: post
title: There'll Be A Hot Time In The Old Town Tonight...IN HELL
date: '2016-09-25 01:00:00'
tags:
- sermon
- gospel-of-luke
- lazarus
---

<div class="storify"><iframe src="//storify.com/pastordan/there-ll-be-a-hot-time-in-the-old-town-tonight-in-/embed?template=slideshow" width="100%" height="750" frameborder="no" allowtransparency="true"></iframe><script src="//storify.com/pastordan/there-ll-be-a-hot-time-in-the-old-town-tonight-in-.js?template=slideshow"></script><noscript>[<a href="//storify.com/pastordan/there-ll-be-a-hot-time-in-the-old-town-tonight-in-" target="_blank">View the story "There'll be a hot time in the old town tonight - in HELL" on Storify</a>]</noscript></div>