---
layout: post
title: People, Get Ready
date: '2016-12-04 01:00:00'
tags:
- sermon
- isaiah
---

Disregard the image below. You'll know it when you see it. Disregard it! 

This is a sermon about preparing for Christ's return. You can also read it [on Storify](https://storify.com/pastordan/people-get-ready) if the embed below doesn't work or simply annoys you.

Disregard the image!

<div class="storify"><iframe src="//storify.com/pastordan/people-get-ready/embed?template=slideshow" width="100%" height="750" frameborder="no" allowtransparency="true"></iframe><script src="//storify.com/pastordan/people-get-ready.js?template=slideshow"></script><noscript>[<a href="//storify.com/pastordan/people-get-ready" target="_blank">View the story "People, get ready" on Storify</a>]</noscript></div>