---
layout: post
title: And Rastas call Africa "Zion," too
date: '2016-11-27 01:00:00'
tags:
- sermon
- isaiah
---

Here's a sermon preached on November 27, 2016, from [Isaiah 2:1-5](http://bible.oremus.org/?ql=347294738). If the slideshow below doesn't work for you, you can see it directly on [Storify](http://storify.com/pastordan/still-later-zion-became-utah).

<div><iframe src="http://storify.com/pastordan/still-later-zion-became-utah.html"></iframe></div>